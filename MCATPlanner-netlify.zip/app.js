const TOTALS = {
  uworld: { "UWorld C/P": 1192, "UWorld B/B": 875, "UWorld CARS": 463, "UWorld P/S": 289 },
  aamc: { "AAMC Biology/Biochem.": 340, "AAMC C/P": 340, "AAMC Independent": 150, "AAMC CARS": 575 }
};
const COLORS = {
  "UWorld C/P": "var(--uw-cp)", "UWorld B/B": "var(--uw-bb)", "UWorld CARS": "var(--uw-cars)", "UWorld P/S": "var(--uw-ps)",
  "AAMC Biology/Biochem.": "var(--aamc-bio)", "AAMC C/P": "var(--aamc-cp)", "AAMC Independent": "var(--aamc-independent)", "AAMC CARS": "var(--aamc-cars)"
};
const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const STORAGE_KEY = "mcat-prep-plan-v1";
let state = loadState();
let currentView = "today";
let displayedMonth = firstOfMonth(new Date());

function loadState() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) return JSON.parse(saved);
  const exam = new Date(); exam.setDate(exam.getDate() + 100);
  return { examDate: iso(exam), fullLengthDay: "Saturday", breaks: [], unavailable: "", targets: {}, completed: {}, tasks: {}, fullLengths: {} };
}
function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function iso(date) { return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
function parseDate(value) { const date = new Date(`${value}T12:00:00`); return Number.isNaN(date.getTime()) ? null : date; }
function firstOfMonth(date) { return new Date(date.getFullYear(), date.getMonth(), 1, 12); }
function dateKey(date) { return iso(date); }
function addDays(date, amount) { const result = new Date(date); result.setDate(result.getDate() + amount); return result; }
function esc(value) { return String(value).replace(/[&<>'"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[char])); }
function showToast(message) { const toast = document.querySelector("#toast"); toast.textContent = message; toast.classList.add("show"); setTimeout(() => toast.classList.remove("show"), 2200); }
function sectionClass(section) { return section.toLowerCase().replace(/[^a-z]+/g, "-").replace(/^-|-$/g, ""); }
function targetFor(section) { return state.targets[section] ?? 0; }
function completedFor(section) { return state.completed[section] ?? 0; }
function allSections() { return [...Object.keys(TOTALS.uworld), ...Object.keys(TOTALS.aamc)]; }
function defaultTargets() {
  for (const [section, total] of Object.entries(TOTALS.uworld)) if (state.targets[section] === undefined) state.targets[section] = section === "UWorld CARS" ? total : 0;
  for (const [section, total] of Object.entries(TOTALS.aamc)) if (state.targets[section] === undefined) state.targets[section] = section === "AAMC CARS" ? total : 0;
}
defaultTargets();

function render() {
  document.querySelectorAll(".view").forEach(view => view.classList.toggle("hidden", view.id !== currentView));
  document.querySelectorAll("nav button").forEach(button => button.classList.toggle("active", button.dataset.view === currentView));
  renderToday(); renderSetup(); renderCalendar(); renderProgress();
}
function renderToday() {
  const today = new Date(); const exam = parseDate(state.examDate); const days = exam ? Math.max(0, Math.ceil((exam - today) / 86400000)) : 0;
  const tasks = state.tasks[dateKey(today)] || [];
  const checklist = tasks.length ? tasks.map(task => taskMarkup(task, true)).join("") : '<p class="muted">No assignments for today.</p>';
  const totalDays = exam ? Math.max(1, Math.ceil((exam - today) / 86400000)) : 1;
  const slice = Math.min(360, Math.max(0, Math.round(days / Math.max(totalDays, 1) * 360)));
  document.querySelector("#today").innerHTML = `
    <div class="page-head"><div><div class="greeting">Hello Future Doctor!</div><p class="greeting-sub">Good luck with today's assignment.</p></div><button class="btn dark" data-action="update">Update Calendar</button></div>
    <div class="dashboard">
      <section class="card"><div class="section-title"><h2>Today's checklist</h2><p class="muted">${formatDate(today)}</p></div><div class="stack today-list">${checklist}</div></section>
      <aside class="right-panel stack"><section class="card countdown"><div class="donut" style="--slice:${slice}deg"><div class="donut-value">${days}<small> days left</small></div></div></section><section class="card"><h2>Question progress</h2>${progressMarkup("UWorld", TOTALS.uworld)}${progressMarkup("AAMC", TOTALS.aamc)}</section></aside>
    </div>`;
}
function taskMarkup(task, checkbox) { return `<label class="task ${sectionClass(task.section)}"><input type="checkbox" ${task.done ? "checked" : ""} data-task-date="${task.date}" data-task-index="${task.index}"><span><strong>${esc(task.label)}</strong></span></label>`; }
function progressMarkup(title, group) { return `<div class="section-title" style="margin-top:16px"><strong>${title}</strong></div>${Object.entries(group).map(([section, total]) => { const done = completedFor(section); const pct = total ? Math.min(100, Math.round(done / total * 100)) : 0; return `<div class="progress-row"><div class="progress-head"><span style="color:${COLORS[section]}">${esc(section.replace("UWorld ", "").replace("AAMC ", ""))}</span><span>${done} / ${total}</span></div><div class="progress-track"><div class="progress-fill" style="width:${pct}%;background:${COLORS[section]}"></div></div></div>`; }).join("")}`; }

function renderSetup() {
  const select = (section, total) => { const savedPercent = total ? Math.round(targetFor(section) / total * 100) : 0; return `<select>${[0, 25, 50, 75, 100].map(value => `<option value="${value}" ${value === savedPercent ? "selected" : ""}>${value}%</option>`).join("")}</select>`; };
  const targetRows = (group, key) => Object.entries(group).map(([section, total]) => `<div class="target-row"><strong style="color:${COLORS[section]}">${section}</strong><small>${total} questions</small>${select(section, total)}</div>`).join("");
  document.querySelector("#setup").innerHTML = `<div class="page-head"><div><div class="page-kicker">Plan with intention</div><h1>Build your MCAT plan</h1><p class="muted">Set targets, protected days, and your full-length weekday.</p></div><div class="head-actions"><span class="save-status">Saved automatically</span><button class="btn primary" data-action="generate">Generate Calendar</button></div></div>
    <div class="grid setup-grid"><section class="card setup-card setup-main" style="--accent:var(--teal)"><h2 class="section-title">Exam and schedule</h2><p class="muted setup-lead">Your anchor date controls every full length, break, and workload deadline.</p><div class="form-grid"><label>Exam date<input id="exam-date" type="date" value="${state.examDate}"></label><label>Full-length weekday<select id="fl-day">${DAY_NAMES.slice(1).concat(DAY_NAMES[0]).map(day => `<option ${day === state.fullLengthDay ? "selected" : ""}>${day}</option>`).join("")}</select></label></div><div class="setup-note">The day before the MCAT is automatically protected as a break.</div><h3 style="margin-top:18px">Weekly break days</h3><div class="checks">${DAY_NAMES.map(day => `<label><input type="checkbox" data-break="${day}" ${state.breaks.includes(day) ? "checked" : ""}>${day.slice(0, 3)}</label>`).join("")}</div><label style="margin-top:16px">Unavailable dates, comma-separated<textarea id="unavailable" rows="3" style="width:100%;padding:9px;border:1px solid var(--line);border-radius:5px">${esc(state.unavailable)}</textarea></label></section>
    <section class="card setup-card setup-secondary" style="--accent:var(--uw-cp)"><h2 class="section-title">UWorld targets</h2>${targetRows(TOTALS.uworld, "uworld")}<button class="btn link" data-link="https://www.uworld.com/?srsltid=AU7gw4V3fQJIo5Tajbd8fYy4dEsrb_l3rlcHE4yjxfZssxWl5L95cHku">Open UWorld MCAT ↗</button><p class="setup-note">UWorld CARS defaults to 100%. AAMC CARS is scheduled separately as 3 passages per day.</p></section><section class="card setup-card setup-secondary" style="--accent:var(--aamc-cp)"><h2 class="section-title">AAMC targets</h2>${targetRows(Object.fromEntries(Object.entries(TOTALS.aamc).filter(([section]) => section !== "AAMC CARS")), "aamc")}<button class="btn link" data-link="https://students-residents.aamc.org/prepare-mcat-exam/aamc-mcat-official-prep-updates">Open AAMC Prep Hub ↗</button><p class="setup-note">AAMC CARS includes all 575 questions and is displayed as passages.</p></section></div>`;
}

function readSetup() {
  state.examDate = document.querySelector("#exam-date").value;
  state.fullLengthDay = document.querySelector("#fl-day").value;
  state.unavailable = document.querySelector("#unavailable").value;
  state.breaks = [...document.querySelectorAll("[data-break]:checked")].map(input => input.dataset.break);
  const selects = document.querySelectorAll(".target-row select");
  const sections = [...document.querySelectorAll(".target-row strong")].map(el => el.textContent);
  selects.forEach((select, index) => { state.targets[sections[index]] = Math.round(TOTALS.uworld[sections[index]] || TOTALS.aamc[sections[index]] || 0) * Number(select.value) / 100; });
}
function generatePlan() { readSetup(); const exam = parseDate(state.examDate); if (!exam || exam <= new Date()) return showToast("Choose a future exam date."); state.fullLengths = {}; const dayNumber = DAY_NAMES.indexOf(state.fullLengthDay); for (let i = 0; i < 7; i++) { let date = addDays(exam, -(49 - i * 7)); while (date.getDay() !== dayNumber) date = addDays(date, -1); if (date > new Date()) state.fullLengths[dateKey(date)] = ["Unscored", "FL 1", "FL 2", "FL 3", "FL 4", "FL 5", "FL 6"][i]; } state.fullLengths[state.examDate] = "MCAT EXAM"; state.tasks = buildTasks(exam); saveState(); displayedMonth = firstOfMonth(new Date()); currentView = "today"; render(); showToast("Calendar generated."); }
function availableDays(exam) { const days = []; const start = new Date(); start.setHours(12, 0, 0, 0); const unavailable = state.unavailable.split(",").map(value => value.trim()).filter(Boolean); for (let date = start; date < exam; date = addDays(date, 1)) { const key = dateKey(date); const preExam = key === dateKey(addDays(exam, -1)); if (!unavailable.includes(key) && !state.breaks.includes(DAY_NAMES[date.getDay()]) && !preExam && !state.fullLengths[key]) days.push(date); } return days; }
function buildTasks(exam) { const tasks = {}; const days = availableDays(exam); const aamcCars = Math.ceil(575 / 9); const carsDays = Math.min(days.length, Math.ceil(aamcCars / 3)); const carsRate = carsDays < Math.ceil(aamcCars / 3) ? Math.ceil(aamcCars / carsDays) : 3; let remainingCars = aamcCars; for (let i = days.length - 1; i >= Math.max(0, days.length - carsDays); i--) { const count = Math.min(carsRate, remainingCars); addTask(tasks, days[i], "AAMC CARS", `${count} passages`); remainingCars -= count; } const nonCars = [...Object.keys(TOTALS.uworld).filter(section => section !== "UWorld CARS"), ...Object.keys(TOTALS.aamc).filter(section => section !== "AAMC CARS")]; const allRemaining = nonCars.reduce((sum, section) => sum + Math.max(0, targetFor(section) - completedFor(section)), 0); const uworldRemaining = nonCars.filter(section => section.startsWith("UWorld")).reduce((sum, section) => sum + Math.max(0, targetFor(section) - completedFor(section)), 0); const uworldDays = allRemaining ? Math.max(1, Math.min(days.length, Math.floor(days.length * .4))) : days.length; const activeSections = nonCars.filter(section => targetFor(section) > completedFor(section)); activeSections.forEach(section => { let remaining = Math.max(0, targetFor(section) - completedFor(section)); for (let i = 0; i < days.length && remaining > 0; i++) { const end = section.startsWith("UWorld") ? uworldDays : days.length; if (i >= end) break; const daysLeft = end - i; const amount = Math.max(1, Math.ceil(remaining / daysLeft)); addTask(tasks, days[i], section, `${amount} questions`); remaining -= amount; } }); days.forEach((date, index) => { if (!(tasks[dateKey(date)] || []).some(task => task.section === "AAMC CARS")) addTask(tasks, date, "Jack Westin", `${index === 0 ? 2 : 3} passages`); }); return tasks; }
function addTask(tasks, date, section, detail) { const key = dateKey(date); if (!tasks[key]) tasks[key] = []; tasks[key].push({ date: key, section, label: `${section}: ${detail}`, detail, done: false }); }
function formatDate(date) { return date.toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" }); }

function renderCalendar() { const container = document.querySelector("#calendar"); const monthName = displayedMonth.toLocaleDateString(undefined, { month: "long", year: "numeric" }); const first = firstOfMonth(displayedMonth); const start = addDays(first, -((first.getDay() + 6) % 7)); const exam = parseDate(state.examDate); let cells = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(day => `<div class="weekday">${day}</div>`).join(""); for (let i = 0; i < 42; i++) { const date = addDays(start, i); const key = dateKey(date); const outside = date.getMonth() !== displayedMonth.getMonth(); const special = state.fullLengths[key]; const tasks = state.tasks[key] || []; let body = tasks.map(task => `<div class="day-task" style="color:${task.section === "Jack Westin" ? "#475569" : COLORS[task.section] || "var(--muted)"}">${esc(task.label)}</div>`).join(""); if (special) body = `<div class="day special" style="color:#4f46e5">${esc(special)}</div>`; if (key === dateKey(addDays(exam, -1))) body = `<div class="day special" style="color:#64748b">BREAK</div>`; cells += `<div class="day ${outside ? "outside" : ""}"><div class="day-number">${date.getDate()}</div>${body || "<span class='muted'>No assignments</span>"}</div>`; } container.innerHTML = `<div class="page-head"><div><h1>Study calendar</h1><p class="muted">${exam ? `${Math.max(0, Math.ceil((exam - new Date()) / 86400000))} days until exam` : "Generate a plan first"}</p></div><button class="btn dark" data-action="update">Update Calendar</button></div><section class="card"><div class="calendar-head"><button class="btn" data-month="-1">&larr;</button><h2>${monthName}</h2><button class="btn" data-month="1">&rarr;</button></div><div class="legend"><span class="blue">UWorld C/P</span><span class="green">UWorld B/B</span><span class="red">AAMC C/P / CARS</span><span class="orange">AAMC Independent</span></div><div class="month-grid">${cells}</div></section>`; }
function renderProgress() { const container = document.querySelector("#progress"); const completed = allSections().reduce((sum, section) => sum + completedFor(section), 0); const total = allSections().reduce((sum, section) => sum + (TOTALS.uworld[section] || TOTALS.aamc[section] || 0), 0); const pct = total ? Math.round(completed / total * 100) : 0; container.innerHTML = `<div class="page-head"><div><div class="page-kicker">Keep the momentum visible</div><h1>Progress dashboard</h1><p class="muted">Record completed questions by subsection, then refresh your calendar.</p></div><div style="text-align:right"><span class="completion-chip">${completed.toLocaleString()} / ${total.toLocaleString()} complete</span><button class="btn dark" data-action="update" style="display:block;margin-top:9px">Update Calendar</button></div></div><section class="card" style="margin-bottom:16px;background:linear-gradient(110deg,#142033,#23415d);color:white"><div style="display:flex;justify-content:space-between;gap:14px;align-items:end"><div><div style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#9fd5de;font-weight:800">Overall completion</div><div style="font-size:34px;font-weight:800;margin-top:4px">${pct}%</div></div><div style="text-align:right;color:#c9d7e5;font-size:12px">Every entry is capped<br>at its target total.</div></div><div class="progress-track" style="margin-top:16px;background:#36526e"><div class="progress-fill" style="width:${pct}%;background:#8ce1d6"></div></div></section><div class="grid two">${progressCard("UWorld", TOTALS.uworld, "var(--uw-cp)")}${progressCard("AAMC", TOTALS.aamc, "var(--aamc-cp)")}</div>`; }
function progressCard(title, group, accent) { return `<section class="card progress-card" style="--accent:${accent}"><h2 class="section-title">${title} completed</h2><p class="muted" style="margin-bottom:8px">Enter the questions you have finished.</p>${Object.entries(group).map(([section, total]) => `<label class="progress-input"><span><span style="display:block;color:${COLORS[section]};font-weight:800">${esc(section)}</span><span class="muted">Target: ${total.toLocaleString()} questions</span></span><input type="number" min="0" max="${total}" value="${completedFor(section)}" data-completed="${esc(section)}"></label>`).join("")}</section>`; }
function updateCalendar() { if (!state.examDate || !Object.keys(state.tasks).length) return showToast("Generate a calendar first."); document.querySelectorAll("[data-completed]").forEach(input => state.completed[input.dataset.completed] = Math.max(0, Math.min(Number(input.max), Number(input.value) || 0))); generatePlan(); showToast("Calendar updated from your progress."); }

document.addEventListener("click", event => { const view = event.target.closest("[data-view]"); if (view) { currentView = view.dataset.view; render(); return; } const link = event.target.closest("[data-link]"); if (link) window.open(link.dataset.link, "_blank", "noopener"); const action = event.target.closest("[data-action]"); if (action?.dataset.action === "generate") generatePlan(); if (action?.dataset.action === "update") updateCalendar(); const month = event.target.closest("[data-month]"); if (month) { displayedMonth = new Date(displayedMonth.getFullYear(), displayedMonth.getMonth() + Number(month.dataset.month), 1, 12); renderCalendar(); } });
document.addEventListener("change", event => { if (event.target.matches("[data-completed]")) { state.completed[event.target.dataset.completed] = Math.max(0, Math.min(Number(event.target.max), Number(event.target.value) || 0)); saveState(); renderToday(); } });
document.addEventListener("change", event => { if (event.target.closest("#setup")) { readSetup(); saveState(); showToast("Setup saved automatically."); } });
document.addEventListener("input", event => { if (event.target.closest("#setup")) { readSetup(); saveState(); } });
render();
